package com.example.puzzle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    ImageView current = null;
    private int pair = 0;
    final int[] drawable = new int[]{R.drawable.a, R.drawable.b, R.drawable.c, R.drawable.d, R.drawable.e, R.drawable.f,
            R.drawable.g, R.drawable.h};
    int[] pos = {0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7};
    int currentPosition = -1;

    //chronometer
    private Chronometer chronometer;
    private boolean running;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Game
        setContentView(R.layout.activity_main);

        GridView gridView = (GridView) findViewById(R.id.gridView);
        chronometer = findViewById(R.id.chronometer);

        //Initializing adapter
        adapter adapter = new adapter(this);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (currentPosition < 0) {
                    currentPosition = position;
                    current = (ImageView) view;
                    ((ImageView) view).setImageResource(drawable[pos[position]]);
                } else {
                    if (currentPosition == position) {
                        ((ImageView) view).setImageResource(R.drawable.logo);
                    } else if (pos[currentPosition] != pos[position]) {
                        current.setImageResource(R.drawable.logo);
                        Toast.makeText(getApplicationContext(), "Not Match Try Again!", Toast.LENGTH_SHORT).show();
                    } else {
                        ((ImageView) view).setImageResource(drawable[pos[position]]);
                        pair++;
                        if (pair == 0) {
                            Toast.makeText(getApplicationContext(), "Congratulations..", Toast.LENGTH_SHORT).show();
                        }
                    }
                    currentPosition = -1;
                }
            }
        });

    }

    public void startChronometer(View view){
        if(!running){
            chronometer.setBase(SystemClock.elapsedRealtime());
            chronometer.start();
            running = true;
        }
    }

}